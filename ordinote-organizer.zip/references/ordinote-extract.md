# PDF/PPT/Word/图片/HTML 内容提取

## 功能定义

将 PDF/PPT/Word/图片/HTML 文件中的文字内容提取出来，生成提取稿（中间文档）。本功能**只负责提取与 HTML 结构化清洗**：提取稿**不是最终笔记**，后续通过 `ordinote-wash`（初始化整理，含修错别字、去噪、公式转写等整理规则）或 `ordinote-add`（添加内容）功能将其转化为笔记。Word（.docx）由 `extract_docx.py` 本地转换并保留格式，输出可直接作为正式笔记；自包含 HTML 幻灯片优先用 `wash_html.py` 按语义重建结构并把图片与 SVG 落盘，也可用 `extract_html.py` 只取逐页纯文本。MinerU 云端提取默认只接收 Markdown；JSON 版式信息为可选项，仅在用户显式要求时接收。

---

## 调用脚本提取（文字提取）

1. **选择提取方式**：`scripts/` 目录下提供以下脚本：
   - `scripts/extract_pdf_pptx.py`：本地 Python 脚本直接提取（适用于**文字版** PDF/PPT；详见下文「PDF/PPT 提取」一节；已实现）
   - `scripts/extract_docx.py`：本地 Python 脚本把 **Word（.docx）** 转换为 markdown（保留格式信息；详见下文「Word 提取」一节；已实现）
   - `scripts/wash_html.py`：本地 Python 脚本清洗**自包含 HTML 幻灯片**，按语义重建标题、列表、表格、代码块与图注，图片与内联 SVG 落盘（详见下文「HTML 清洗」一节；**HTML 幻灯片优先用此脚本**；已实现）
   - `scripts/extract_html.py`：本地 Python 脚本逐页提取 HTML 幻灯片的纯文本（详见下文「HTML 提取」一节；适合只需要文字、或清洗脚本还原效果不佳时；已实现）
   - `scripts/mineru_api.py`：调用 MinerU 精准解析 API 提取（适用于扫描件、复杂版式；支持 PDF/PPT/DOC 及**图片**，且支持**一次上传多个文件批量提取**；已实现，需先配置 Token；默认仅输出 Markdown，JSON 需显式开启）
   - 默认先尝试本地脚本；失败或效果差时再改用 MinerU API（旧版 `.doc` 本地脚本不支持：请先用 Word 另存为 `.docx`，或改用 MinerU API）
2. **运行脚本提取文字**，生成提取文件：
   - 输出位置：与源文件同一目录
   - 命名规则：`{原文件名}-提取.md`（或 .txt）；HTML 幻灯片经 `wash_html.py` 清洗时输出 `{原文件名}-整理.md`（详见下文）
   - 可选 JSON 旁证：MinerU 默认不保存 JSON；仅当用户显式要求保留版式/结构信息时，调用时加 `--save-json`，额外生成 `{原文件名}-提取-content_list.json` 与 `{原文件名}-提取-layout.json`。图片暂不导出。
3. **失败处理（必须遵守）**：
   - 脚本无法运行、无法提取、或提取结果为空 → **必须如实告知用户**，说明具体原因
   - 如实告知用户，不要试图用其他方式替代提取
   - 不得编造、猜测或凭记忆补写文件内容
   - 可向用户建议排查方向：文件是否为扫描件、加密、损坏，路径或格式是否有误

---

## PDF/PPT 提取（本地 · scripts/extract_pdf_pptx.py）

从 PDF / PPTX 文件中提取全部文字，生成 markdown 提取稿。适用于**文字版** PDF 与 PPT；扫描版 / 图片型 PDF 提取不到文字时（退出码 2）改用 MinerU API。提取稿是「原始素材」，后续按 `ordinote-wash` 规则整理。脚本只读源文件，不改动源文件。

### 运行

```bash
python scripts/extract_pdf_pptx.py <文件路径> [更多文件路径...] [选项]
```

- 可一次传入多个文件逐个提取；单个文件失败只记录错误，不中断其他文件
- 仅支持 `.pdf` / `.pptx`；旧版 `.ppt` 不支持（退出码 1，提示先用 PowerPoint 另存为 `.pptx`）

### 输出内容

- 输出到源文件同目录，命名为 `{原文件名}-提取.md`（同名旧提取文件会被直接覆盖）
- 各页 / 各张幻灯片之间以 `---` 分隔线分开（保留源结构线索，整理时保留）
- PPT 的演讲者备注以 `> 备注：` 形式附在对应幻灯片之后；表格按制表符分隔保留结构，组合形状内的文字递归提取
- 空白页 / 无文字幻灯片以 HTML 注释占位，便于核对缺页；文件头以 HTML 注释记录来源与提取时间
- 提取完成后打印字符数统计与空白页提醒，供核对提取质量

### 常用选项

| 选项 | 说明 |
|---|---|
| `--no-auto-install` | 缺少依赖库（PyMuPDF / python-pptx）时不自动安装 |
| `--install-deps` | 只安装依赖后退出（供交接前预热） |

退出码：`0` 全部成功；`1` 用法错误 / 文件不存在 / 不支持的类型（含旧版 `.ppt`）；`2` 提取失败或结果为空（典型：扫描版 PDF）；`3` 缺少依赖库 PyMuPDF / python-pptx，且自动安装被拒绝或失败

---

## Word 提取（本地 · scripts/extract_docx.py）

将 Word（.docx）转换为 markdown，尽可能保留 Word 的格式信息。适用于**AI 生成正文、楷体手写批注**的 Word 笔记（如各版本纵向笔记）。脚本只读源文件，不修改 Word 文档。

### 运行

```bash
python scripts/extract_docx.py <文件或目录> [更多...] [选项]
```

- 目录输入会处理其下所有 `.docx`（不递归）；单个文件失败只记录错误，不中断其他文件
- 旧版 `.doc` 不支持（退出码 1，提示先用 Word 另存为 `.docx`，或改用 MinerU API）

纵向笔记场景常用组合（批量转换存档目录、去除版本号、输出到正式笔记目录）：

```bash
python scripts/extract_docx.py "archives\纵向笔记（临时）" --strip-version --out "纵向笔记"
```

### 格式保留与项目约定

- 标题：首段为「无缩进 / No Spacing / Title / 标题」样式时作为文档主标题输出 `#`，其余标题样式顺延一级（`Heading 1` → `##`）
- 生成信息行：第二段整行斜体（本项目约定）
- 行内格式：加粗、斜体、粗斜、删除线、下划线 `<u>`、荧光高亮 `<mark>`
- 批注字体（默认 楷体/KaiTi/SimKai）→ 淡灰色 `<mark>` 包裹；本项目约定**霞鹜文楷为 AI 生成正文、楷体为手写批注**，精确匹配不误伤霞鹜文楷
- Cambria Math 公式字体中的粗体/斜体视为数学排版样式，不转为强调
- 列表（多级嵌套与编号计数）、表格（pipe 表格，合并单元格去重）、超链接、引用样式（相邻引用段合并）、软回车 `<br>`
- 内嵌图片导出到输出目录 `assets/` 子文件夹，正文以相对路径引用
- 不保留 / 不提取：字号、颜色、对齐等 markdown 无法表达的格式；页眉页脚、脚注尾注、文本框、审阅批注；修订删除的内容

### 常用选项

| 选项 | 说明 |
|---|---|
| `--out <目录>` | 输出目录（默认：源文件所在目录） |
| `--suffix <后缀>` | 输出文件名后缀：`{名}-{后缀}.md`（默认：无） |
| `--strip-version` | 去除文件名末尾 `_v` / `_v0.5` 之类版本号 |
| `--annotation-fonts <字体>` | 批注字体，逗号分隔（默认：楷体,KaiTi,SimKai） |
| `--no-annotation` | 不做批注字体标记 |
| `--no-title-shift` | 首段不作为文档主标题，标题保持原层级 |
| `--no-meta-italic` | 第二段不做整行斜体处理 |
| `--no-images` | 不导出内嵌图片（以 HTML 注释占位） |
| `--no-auto-install` | 缺少 python-docx 时不自动安装 |

退出码：`0` 全部成功；`1` 用法错误 / 不支持的类型（含旧版 `.doc`）；`2` 转换失败或结果为空；`3` 缺少依赖 python-docx，且自动安装被拒绝或失败

---

## HTML 清洗（推荐 · scripts/wash_html.py）

在逐页文字提取之后增加清洗步骤：按 HTML 语义标记重建笔记结构，并把页内资源落盘。对 class 命名规范的幻灯片模板（如课程讲义模板）可一步完成“提取 + 清洗”；结构松散的页面也可用，层级还原依赖标签本身。脚本只读源文件，只依赖标准库。

### 运行

```bash
python scripts/wash_html.py <文件或目录> [更多...] [选项]
```

- 文件输入：一个或多个 `.html`；目录输入：处理其下所有 `.html`（不递归）
- `--out` 只能用于单个输入文件；批量输入用 `--outdir` 改输出目录

### 识别规则与输出内容

- 分页：`class` 含独立单词 `slide` 的 `section` / `div` / `article` 视为一页；找不到时依次退回多 `section` 结构、整篇 `body` 一页；页间以 `---` 分隔
- 去噪：`footer`、`nav`、`termbar`、目录跳转行等装饰不写入正文；页码只并入标题编号（如 `### 1.2 · ...`）
- 结构：标题层级（封面 `#`、Part 页 `##`、普通内容页 `###`）、导读句、要点列表（含嵌套）、表格、代码块、图注、定义列表、引用、折叠块按语义还原；跨列行转为表格后的注释，目录页汇总为表格
- 代码块：优先取 `class="language-xxx"`；没有时按首行与命令词判定 `bash` / `text`
- 资源：data URI 图片解码落盘；内联 SVG 存为独立 `.svg` 并恢复 `viewBox` 等驼峰属性；相对路径图片按需复制；正文以相对路径引用。图片写入 `{资源根}/images/{前缀}-figs/`，SVG 写入 `{资源根}/svgs/{前缀}-svgs/`
- 相对路径图片缺失时不写入正文，完成后汇报缺失数量；远程图片保留原 URL
- 输出到源文件同目录，命名为 `{原文件名}-整理.md`；同名旧稿会被直接覆盖，`--skip-existing` 可跳过已存在的输出

### 常用选项

| 选项 | 说明 |
|---|---|
| `--out <文件>` | 指定输出文件（仅单输入） |
| `--outdir <目录>` | 输出目录，默认与源文件同目录 |
| `--assets <目录>` | 图片与 SVG 的资源根目录，默认输出目录下的 `assets` |
| `--prefix <前缀>` | 资源命名前缀，默认取文件名开头的编号（如 `L2`），否则为 `deck` |
| `--skip-existing` | 输出已存在时跳过 |

退出码：`0` 全部成功；非 `0` 失败（参数错误、输入无效或读写异常）

---

## HTML 提取（本地 · scripts/extract_html.py）

从自包含 HTML 幻灯片中逐页提取文字，生成 markdown 提取稿。适用于 HTML 导出的演示文稿（每页由独立容器包裹）；脚本只读源文件，只依赖标准库。页面结构规范时优先用上一节的 `wash_html.py`，本脚本适合只需要文字、或清洗脚本还原效果不佳的情况。

### 运行

```bash
python scripts/extract_html.py <文件路径> [更多文件路径...] [选项]
```

- 可一次传入多个 `.html` / `.htm` 文件逐个提取；单个文件失败只记录错误，不中断其他文件

### 识别规则与输出内容

- 容器：`class` 中含有独立单词 `slide` 的 `section` / `div` / `article` 视为一张幻灯片
- 忽略内容：`style` / `script` / `noscript` / `template` 中的内容不提取
- 文本结构：块级元素换行；表格单元格以 ` | ` 分隔；图片记为 `[IMG]` 或 `[IMG:alt]`
- 找不到幻灯片容器时，退化为整份 `body` 作为单页输出（适合单篇 HTML 报告）
- 输出到源文件同目录，命名为 `{原文件名}-提取.md`；各张幻灯片之间以 `---` 分隔线分开（保留源结构线索，整理时保留）
- 无文字幻灯片以 HTML 注释占位；文件头以 HTML 注释记录来源、页数与提取时间
- 提取完成后打印页数与字符数统计，供核对提取质量

### 常用选项

| 选项 | 说明 |
|---|---|
| `--no-images` | 图片只记 `[IMG]`，不记 `alt` 文本 |

退出码：`0` 全部成功；`1` 用法错误 / 文件不存在 / 不支持的类型（仅支持 `.html` / `.htm`）；`2` 提取失败或结果为空

---

## MinerU API 提取（云端备选 · scripts/mineru_api.py）

当本地脚本无法提取（典型：扫描版 / 图片型 PDF）或提取效果差时，改用 MinerU 精准解析 API。

### Token 配置（首次使用必做）

1. 登录 <https://mineru.net/apiManage/docs>，进入「API 管理」页，自行创建一个 Token
2. 用 **PowerShell 命令**把 Token 配置为环境变量（脚本只从环境变量读 Token，不在磁盘上留明文 Token 文件）：

   **永久配置（推荐，一次性）**——写入用户环境变量，重开终端 / Trae 后生效：
   ```powershell
   [Environment]::SetEnvironmentVariable("MINERU_API_TOKEN", "你的token", "User")
   ```

   仅当前会话有效（临时测试用）：
   ```powershell
   $env:MINERU_API_TOKEN = "你的token"
   ```

   验证是否配置成功：
   ```powershell
   [Environment]::GetEnvironmentVariable("MINERU_API_TOKEN", "User")
   ```

   macOS / Linux（写入 shell 配置，永久生效）：
   ```bash
   echo 'export MINERU_API_TOKEN="你的token"' >> ~/.zshrc   # 或 ~/.bashrc
   ```

- 也支持临时参数 `--token 你的token` 覆盖环境变量（不推荐长期使用：会遗留在命令历史里）
- 优先级：`--token` > 环境变量 `MINERU_API_TOKEN`

- 如果上述任务无法完成，则将对应步骤告知用户

### 运行

```bash
python mineru_api.py <文件路径> [更多文件路径...]
```

常用选项：

| 选项 | 说明 |
|---|---|
| `--token <token>` | 临时指定 Token，覆盖环境变量（不推荐长期使用，会留在命令历史里） |
| `--model <name>` | 模型版本：`vlm`（脚本默认，推荐）/ `pipeline` / `MinerU-HTML` |
| `--pages <范围>` | 只解析指定页码，如 `1-200`、`2,4-6`；用于超长/超页文档分批解析 |
| `--no-ocr` | 关闭 OCR（默认开启；扫描件建议保持开启） |
| `--save-json` | 额外保存 `content_list.json` 与 `layout.json` 旁证文件（默认关闭；仅用户显式要求版式信息时使用） |
| `--timeout <秒>` | 等待解析结果的超时，默认 900 秒 |
| `--no-auto-install` | 缺依赖库（requests）时不自动安装 |
| `--install-deps` | 只安装依赖后退出 |

### JSON 旁证输出（默认关闭）

MinerU 结果压缩包里除 `full.md` 外还有 `content_list.json`、`layout.json`、`model.json`。本脚本默认只取 `full.md`，不保存任何 JSON，行为与旧版一致。

只有用户显式要求保留版式/结构信息（例如「同时保留 JSON」「保留版式信息」）时，才加 `--save-json`：

```bash
python mineru_api.py 讲义.pdf --save-json
```

此时每个源文件除 `{原文件名}-提取.md` 外，还会在同目录写出：

- `{原文件名}-提取-content_list.json`：按阅读顺序的内容列表，含 `page_idx`、内容类型、`text_level`、bbox、表格 HTML、图注表注
- `{原文件名}-提取-layout.json`：即 middle.json，含页内块与行的几何、字号、页眉页脚等 discarded 块

约定：

- 不保存 `model.json`：模型原始推理结果体积大，对整理没有直接价值
- 不解压 `images/`：正文中的图片引用保持 MinerU 原始相对路径
- JSON 只作旁证文件，不并入提取稿正文；整理时按需查阅，不整份读入上下文
- 未显式要求时不得自行加 `--save-json`

### 支持的文件类型与批量上传

**一、支持图片（可直接上传图片提取文字）**

MinerU 不仅能解析 PDF/PPT，还能**直接上传图片**提取文字（等价于对图片做 OCR）。支持的输入格式：

- 文档：`pdf` / `doc` / `docx` / `ppt` / `pptx`
- 图片：`png` / `jpg` / `jpeg` / `jp2` / `webp` / `gif` / `bmp`

把图片路径当成普通文件传给脚本即可（OCR 默认开启，正适合图片/扫描件；如需关闭用 `--no-ocr`）：

```bash
python mineru_api.py 扫描页1.png 扫描页2.jpg
```

**二、支持一次上传多个文件（批量）**

脚本可接收多个文件路径，**一次性批量提交解析**，PDF 与图片可混在一起；每个文件各自生成 `{原文件名}-提取.md`。文件较多时会自动分批（脚本每批 ≤ 50 个，官方单批上限 200 个）：

```bash
python mineru_api.py 第一章.pdf 第二章.pdf 架构图.png
```

注意：

- 批量中的**每个文件都各自遵守 200 MB / 600 页上限**（不是合计上限）
- 批量上传与图片解析不影响 Token 配置和输出命名规则
- 若同一批里存在同名文件，结果可能互相覆盖，脚本会给出提醒

### 与本地脚本的差异

- 输出同样为 `{原文件名}-提取.md`，但**正文中没有 `---` 分页线**：MinerU 只返回整篇 Markdown（取自结果压缩包的 `full.md`），不返回逐页文字；需要页码时显式加 `--save-json`，从 `content_list.json` 的 `page_idx` 获取
- JSON 为可选输出：默认不接收任何 JSON；显式 `--save-json` 时保存 `content_list.json` 与 `layout.json`（不保存 `model.json`）
- 图片不导出：结果包中的 `images/` 不解压，`full.md` 里的图片引用保持原始相对路径
- Word（`.docx`）提取优先用本地 `scripts/extract_docx.py`；旧版 `.doc`、扫描件或复杂版式的 Word 文档可改用 MinerU API
- 内容为 MinerU 解析后的干净 Markdown（含公式 LaTeX、表格等）；后续用 `ordinote-wash` 整理时仍要检查有无缺页
- 单文件大小上限 200 MB、页数上限 600 页（精准解析 API 官方限制）；多个文件会自动分批（每批 ≤ 50 个）上传解析
- 超过 600 页的超长文档：用 `--pages` 按页范围多次提取（如 `--pages 1-600`、`--pages 601-1200`），再人工/后续功能合并
- 注意：网上常见的"10 MB / 20 页"限制属于 **Agent 轻量解析 API**（免登录那个），与我们使用的精准解析 API 无关

---

## 注意事项

1. **不删除原始提取文件**（`{原文件名}-提取.md`）：它是核对提取质量的依据；用户要求删除时才删除。HTML 清洗稿 `{原文件名}-整理.md` 与 `assets` 下已落盘的图片/SVG 同样不删除，用户要求时才删除
2. **汇报义务**：完成后向用户汇报——提取方式、生成的文件、提取质量（是否完整、有无乱码或缺页）；启用 `--save-json` 时一并说明生成的 JSON 文件
3. **JSON 旁证文件为可选产物**：未显式要求时不生成；**已生成时也不并入提取稿正文**，整理时按需查阅，不整份读入上下文

